<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('Beranda');
	}

	public function Tentang()
	{
		$this->load->helper('url');
		$this->load->view('Tentang');
	}
	public function Kontak()
	{
		$this->load->helper('url');
		$this->load->view('Kontak');
	}
	
}