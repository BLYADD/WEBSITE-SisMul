<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Beranda - Web Pribadi</title>
</head>
<body>
    <marquee behavior="scroll" direction="left">Selamat datang di website pribadi saya!</marquee>
    <h1>Halo, saya Alfin</h1>
    <p>Ini adalah halaman beranda dari web pribadi saya.</p>

    <!-- Tambahkan gambar -->
    <img src="/CI3Web/assets/images/phoenix.jpg" alt="Gambar Phoenix" style="width:300px;">

    <!-- Tambahkan video -->
<video width="320" height="240" controls autoplay loop>
    <source src="/CI3Web/assets/videos/ElevenLabs_2025-05-08T07_13_39_Putra_pvc_sp91_s50_sb75_se0_b_m2.mp4" type="video/mp4">
    Browser Anda tidak mendukung tag video.
</video>



    <br>
    <a href="<?php echo site_url('welcome/tentang'); ?>">Tentang Saya</a> |
    <a href="<?php echo site_url('welcome/kontak'); ?>">Kontak</a>

    <audio controls autoplay loop>
    <source src="https://files.catbox.moe/h789jt.mp3" type="audio/mpeg">
    Browser Anda tidak mendukung tag audio.
</audio>
</body>
</html>
