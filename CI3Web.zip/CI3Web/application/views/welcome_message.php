<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Beranda - Web Pribadi</title>
</head>
<body>
    <marquee behavior="scroll" direction="left">Selamat datang di website pribadi saya!</marquee>
    <h1>Halo, saya [Alfin]</h1>
    <p>Ini adalah halaman beranda dari web pribadi saya.</p>
    <a href="<?php echo site_url('welcome/tentang'); ?>">Tentang Saya</a> |
    <a href="<?php echo site_url('welcome/kontak'); ?>">Kontak</a>
</body>
</html>
