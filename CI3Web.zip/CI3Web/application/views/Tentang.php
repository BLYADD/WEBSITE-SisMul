<!DOCTYPE html>
<html>
<head>
    <title>Tentang Saya</title>
</head>
<body>
    <h1>Tentang Saya</h1>
    <p>Perkenalkan, saya adalah seorang mahasiswa/pekerja/kreator konten, dll.</p>
    <a href="<?php echo site_url('welcome'); ?>">Kembali ke Beranda</a>
</body>
</html>
