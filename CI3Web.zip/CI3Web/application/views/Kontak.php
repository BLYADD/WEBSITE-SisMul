<!DOCTYPE html>
<html>
<head>
    <title>Kontak</title>
</head>
<body>
    <h1>Hubungi Saya</h1>
    <p>Email: kamu@email.com</p>
    <p>Instagram: @kamu</p>
    <a href="<?php echo site_url('welcome'); ?>">Kembali ke Beranda</a>
</body>
</html>
